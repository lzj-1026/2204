
// 获取点击加载更多按钮
var jz = document.getElementsByClassName("jz")[0];
// 获取正在加载中按钮
var jzz = document.getElementsByClassName("jzz")[0];
// 点击时加载数据
jz.addEventListener("click", function () {
    jz.style.display = "none";
    jzz.style.display = "inline-block";
    function show_() {
        var ajax_ = new XMLHttpRequest() || new ActiveXObject("Microsoft.XMLHTTP");
        ajax_.open("get", "http://127.0.0.1:3000/useing/public", true);
        ajax_.send();
        ajax_.onreadystatechange = function () {
            if (ajax_.readyState === 4) {
                if (ajax_.status === 200) {
                    var data = JSON.parse(ajax_.responseText);
                    // console.log(data);
                    show(data);
                }
            }
        }
        function show(data) {
            var str = '';
            for (item of data) {
                str += `
<div>
<a href="#">
<span>${item.info_ty}</span>
<img src="${item.img}">
<h3>${item.text}</h3>
<p><span>2032</sapn>
<span>23台</sapn>
</p>
<p><span>1932</span>申请</p>
<p><span>报告数量：8</span></p>
</a>
</div>
`
            }
            console.log(str);
            var div = document.querySelector('main')
            var div_ = document.createElement('div')
            div_.className = "m_a"
            div_.innerHTML = str;
            div.appendChild(div_);
            // var div = document.createElement("div")
            // div.className = "m_m"
            // div_.appendChild(str)

        }
    }
    setTimeout(function () {
        show_();
        jz.style.display = "inline-block";
        jzz.style.display = "none";
    }, 1000);
});
