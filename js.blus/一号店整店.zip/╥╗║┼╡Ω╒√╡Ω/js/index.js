var mb_ = document.getElementsByClassName("nnn")[0]
var bl_ = document.getElementsByClassName("mb")[0]
function yiru() {
    bl_.style.display = 'block';
}
function yichu() {
    bl_.style.display = 'none';
}
var nav = document.getElementsByClassName('nav_a')[0]
// console.log(nav);

var xian_ = document.getElementsByClassName('xian')[0]
xian_.onmouseenter = function () {
    nav.style.display = 'block'
}
xian_.onmouseleave = function () {
    nav.style.display = 'none'
}

// 购物车
var inner_ = document.getElementsByClassName('inner')[0]; //car
// console.log(inner_);
var in_s = document.getElementsByClassName('in_s')[0];//shops
// console.log(in_s);
function fn() {
    inner_.style.display = 'block'
}
function fn_() {
    inner_.style.display = 'none'
}
var in_a_ = document.getElementsByClassName('in_a')[0]
// console.log(in_a);
var sc_ = document.getElementsByClassName('sc')[0]
// console.log(sc_);
var kong_ = document.getElementsByClassName('kong')[0]
// var in_a_ = Array.from(in_a)

var ul_ = document.getElementById('i_ul')
for (var i = 0; i < sc_.length; i++) {
    sc_[i].onclick = function (e) {
        e = e || window.event;
        confirm('确认删除吗？')
        ul.removeChild(this.parenrNode.parentNode.parentNode);
        in_a_.length--;
        if (in_a_.length == 0) {
            in_s.parentNode.removeChild(in_s);
            kong_.style.display = 'block';

            inner_.onmouseenter = function () {
                kong_.style.display = 'block';
            }

            inner_.onmouseleave = function () {
                kong_.style.display = 'none';
            }
        }
    }
}

var jia_ = document.getElementById('jia')
console.log(jia_);
var jian_ = document.getElementsByClassName('jian')[0]
var shu_ = document.getElementsByClassName('shu')[0]
console.log(shu_);
var danjia_ = document.getElementsByClassName('danjia')[0]
var je_ = document.getElementsByClassName('je')[0]
var sum_ = document.getElementsByClassName('sum_')[0]
var money = [];//qian
for (var i = 0; i < danjia_.length; i++) {
    var arr = danjia_[i].innerHTML;
    money.push(arr);
    // 增加个数
    jia_[i].onclick = function () {
        shu_[i].value++;

        dianjia_[i].innerHTML = money[i] * shu_[i].value;//单个商品价格
        sum_()
    }
    // 减
    jian_[i].onclick = function () {
        shu_[i].value--;
        if (shu_[i].value <= 0) {
            confirm('您要删除这件宝贝吗？')
            if (confirm) {
                ul.removeChild(this.parenrNode.parentNode.parentNode.parentNode);
                in_a_.length--;
                if (in_a_.length <= 0) {
                    in_s.parentNode.removeChild(shops);
                    kong_.style.display = 'block';

                    inner_.onmouseenter = function () {
                        kong_.style.display = 'block';
                    }

                    inner_.onmouseleave = function () {
                        kong_.style.display = 'none';
                    }

                }

            }
        }
        danjia_[i].innerHTML = money[i] * shu_[i].value
        sum_()
    }
    function sum_() {

        var shu_ = document.getElementsByClassName('shu')[0]//个数
        var danjia_ = document.getElementsByClassName('danjia')[0]//小计

        var sum = 0
        var num = 0
        for (var i = 0; i < danjia_.length; i++) {
            // sum = sum + 小计的数字  
            sum = sum + parseInt(danjia_[i].innerHTML)
            num = num + Number(shu_[i].value) //还可以使用number转换为数字型
        }
        // console.log(num);
        je_.innerHTML = '立即结算(' + num + ')'
        sum_.innerHTML = '合计 ￥' + sum
    }
    sum_()


}













// for (var i = 0; i < mb_.length; i++) {
//     this.bl_.style.display = "block";

// }
// console.log(mb_);
// for (var i = 0; i < mb_.length; i++) {
//     mb_[i].index = i;
//     mb_[i].addEventListener('mouseover', function () {
//         for (var j = 0; j < bl_.length; j++) {
//             mb_[i].className = ''
//             bl_[j].style.display = "none"
//         }
//         bl_[this.index].style.display = "block"
//     })

// }
// box.addEventListener('mouseout', function () {
//     border.className = "nnn";
// })
// // 离开主菜单，子菜单隐藏
// topbox.addEventListener('mouseout', function () {
//     border.className = "nnn";
// })
// // 移入子菜单,子菜单显示
// border.addEventListener('mouseover', function () {
//     this.className = "nnn";
// })
// function yiru() {
//     var li_ = document.getElementById('ul__').children[0]
//     var mb_ = document.getElementsByClassName('mb')
//     for (var i = 0; i < li_.length; i++) {
//         console.log(li_[i]);
// li_[i].
//     } mb_.style.display = "block";
//     console.log(mb_);
// }